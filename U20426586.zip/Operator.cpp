#include "Operator.h"
using namespace std;

template<class T>
Operator<T>::Operator()
{
	//should be left empty
}

template<class T>
Operator<T>::~Operator()
{
	//should be left empty
}
